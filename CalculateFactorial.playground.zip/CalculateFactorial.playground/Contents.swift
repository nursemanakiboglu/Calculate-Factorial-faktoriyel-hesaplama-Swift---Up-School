import UIKit

class Program
{
    func factorial (number : Int) -> Int
    {
        var fact = 1
        var n = number
        
        while n > 0
        {
            fact = fact * n
            n = n - 1
        }
        return fact
    }
}
let x = Program()
let result = x.factorial(number: 5)

print("Result is : \(result)")


